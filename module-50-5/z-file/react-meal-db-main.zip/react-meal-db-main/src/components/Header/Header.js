import React from 'react';

const Header = () => {
    return (
        <div>
            <h2>Welcome to My Restaurant</h2>
            <h4>Please order the food you like</h4>
        </div>
    );
};

export default Header;